USE [AdventureWorks2014]
GO

/****** Object:  Table [dbo].[Employee_Table]    Script Date: 01-Feb-19 10:51:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
DROP TABLE IF EXISTS [dbo].[Employee_Table]
GO
CREATE TABLE [dbo].[Employee_Table](
    [BusinessEntityID] INT NULL,
	[fname] [nvarchar](400) NULL,
	[lname] [nvarchar](400) NULL,
	[loginid] [nvarchar](400) NULL,
	[gender] [nvarchar](1) NULL
) ON [PRIMARY]
GO


