CREATE TABLE GenderLookup (GenderCode nchar(1), GenderName varchar(max));
INSERT INTO GenderLookup VALUES('M','Male'),('F','Female');
SELECT * FROM GenderLookup;